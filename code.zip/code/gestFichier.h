

char* chargerFichier(char* nomFichier);

int tailleFichier(char* nomFichier);
