
#ifndef FA
#define FA

char* enMinuscule(char* str);


#endif
