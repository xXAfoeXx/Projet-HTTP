
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "foncParseur.h"
#include "arbre.h"
#include "foncAnnexe.h"

noeud* parse(char* str, int taille){
  noeud* rac = crRacine(str, "HTTP-message", taille);

  // Si il y a une erreur dans la requête, le parsing est stoppe, l'arbre est vide
  //Et on renvoie ensuite un pointeur NULL
  if(http_message_parse(rac)){
    viderArbre(rac);
    rac = NULL;
  }


  return rac;
}

int http_message_parse(noeud* pere){

  int start = 0;
  int first = 1;

  for(int i = 0; i < pere->size; i++){
    //Si on tombe sur un retour a la ligne et qu'il n'y a pas d'espace
    if(pere->value[i] == '\n' && pere->value[i-1] != '\n' && pere->value[i-2] != '\n' && pere->value[i+1] != ' ' && pere->value[i+1] != '\t'){

      if (first) {
         if(start_line_parse(crFils(pere, pere->value+start, "start-line", i-start))) return 1;
         first = 0;
      }
      else {
        if(header_field_parse(crFils(pere, pere->value+start, "header-field", i-start))) return 1;
      }

      i++;
      start = i; //+1 pour le retour a la ligne supprime
    }
  }

  return 0;
}

int start_line_parse(noeud* pere){

  int i = 0;
  char* str;

  while(i < pere->size && pere->value[i] != ' '){
    i++;
  }

  str = strParSize(pere->value, i);

  // Pour ce projet on ne considere que les requetes
  // Ainsi, si on tombe sur autre chose qu'un GET
  //On quitte de suite le programme

  if(!strcmp(str, "GET")){
    if(request_line_parse(crFils(pere, pere->value, "request-line", pere->size))) return 1;
    free(str);
  }
  else{
    printf("Cette requete n'en est pas une : %s\n", str);
    free(str);
    return 1;
  }


  return 0;
}


int request_line_parse(noeud* pere){

  int sp = 0;
  int start = 0;

  for(int i = 0; i < pere->size; i++){
    if(pere->value[i] == ' ' || i == pere->size-1){
      if(sp == 0){ // Au premier espace
        if(!is_token(crFils(pere, pere->value+start, "method", i-start))) return 1;
        start = i + 1;
        sp++;
      }
      else if(sp == 1){ // Au 2e
        request_target_parse(crFils(pere, pere->value+start, "request-target", i-start));
        start = i + 1;
        sp++;
      }
      else if(sp == 2){ // Au 3e
        if(http_version_parse(crFils(pere, pere->value+start, "HTTP-version", i-start))) return 1;
        start = i + 1;
        sp++;
      }
    }
  }

  return 0;
}

int http_version_parse(noeud* pere){

  int start = 0;
  int i = 0;
  int slash = 0;

  while(pere->size > i){

    if(pere->value[i] == '/' && !slash){

      crFils(pere, pere->value+start, "HTTP-version", i-start);
      i++;
      start = i;
      if(!is_digit(pere->value[i])) {
        printf("->Erreur digit\n");
        affNoeud(pere);
        return 1;
      }
      if(!is_digit(pere->value[i+2])) {
        printf("->Erreur digit\n");
        affNoeud(pere);
        return 1;
      }
      slash = 1;
    }
    else if(slash && i-start >= 3){
      printf("->Erreur longueur digit\n");
      affNoeud(pere);
      return 1;
    }

    i++;
  }

  return 0;
}


noeud* request_target_parse(noeud* pere){

  int i = 0;

  //On identifie le type de requete cible via leur synthax
  if (pere->value[0] == '/') {
    crFils(pere, pere->value, "absolute-path", pere->size);
  }
  else if (pere->value[0] == '*') {
    crFils(pere, pere->value, "asterisk-form", pere->size);
  }
  else{
    while(i < pere->size && (pere->value[i] != ':' || pere->value[i] != '@')){
      i++;
    }
    if (pere->value[i] == ':') {
      if(absolute_uri(crFils(pere, pere->value, "absolute-URI", pere->size))) return 1;
    }
    else if (pere->value[i] == '@') {
      crFils(pere, pere->value, "authority", pere->size);
    }
  }

  return pere;
}



int header_field_parse(noeud* pere){
  char* hn;
  noeud* fils;
  int end = 0;
  for(int i = 0; i < pere->size; i++){
    if(pere->value[i] == ':'){
      hn = strParSize(pere->value, i);//On recupere la chaine en fonction du pointeur et de la taille.
      hn = enMinuscule(hn);//Conversion en minuscule pour ne pas se soucier de la casse

      //+1 pour le ':'
      i++;
      OWS(pere->value, &i);//elimine les OWS entre : et la valeur

      int j = i;
      //Permet de retirer les OWS en fin de header field
      while(j < pere->size){
        end = OWS(pere->value, &j);
        j++;
      }

      fils = crFils(pere, pere->value+i, hn, pere->size-i-end);

      if(!strcmp(hn, "connection")){
        if(connection_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "user-agent")){
        if(user_agent_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "accept")){
        if(accept_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "accept-language")){
        if(accept_language_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "accept-encoding")){
        if(accept_encoding_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "content-length")){
        if(content_length_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "content-type")){
        if(content_type_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "cookie")){
        if(cookie_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "transfer-encoding")){
        if(transfer_encoding_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "expect")){
        if(expect_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "host")){
        if(host_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "accept-charset")){
        if(accept_charset_parse(fils)) return 1;
      }
      else if(!strcmp(hn, "referer")){
        if(referer_parse(fils)) return 1;
      }
      else{
        if(unkw_field_parse(fils)) return 1;
      }



      //free(hn);
      //Besoin ici de garder le pointeur, probleme de memoire ?
      return 0;
    }
  }

  affNoeud(pere);
  printf("Erreur header-name\n");
  exit(3);
}



int connection_parse(noeud* pere){

  int i = 0;
  int start = 0;
  //Manipulation si le champ commence par "," OWS
  if(pere->value[i] == ','){
    i += 1;
    OWS(pere->value, &i);
  }
  start = i;

  while(i < pere->size){

    //Si on est en fin de ligne ou qu'il y a un separateur on cree un nv fils
    if(i == pere->size-1 || pere->value[i] == ','){

      if(!is_token(crFils(pere, pere->value+start, "connection_option", i-start))){
        return 1;
      }
      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
    }

    i++;
  }

  return 0;
}

int user_agent_parse(noeud* pere){

  int start = 0;
  int com = 0;
  int i = 0;

  while(i < pere->size){

    // Separateur : ' ' ou tab ou fin de ligne sauf si dans dans un commentaire
    if(com == 0 && (pere->value[i] == ' ' || pere->value[i] == '\t' || i == pere->size-1)){

      //Si ce n'est pas un commentaire, ca ne commence pas par une parenthese
      if(pere->value[start] != '('){
        if(product_parse(crFils(pere, pere->value+start, "product", i-start))) return 1;
      }
      else{
        crFils(pere, pere->value+start, "comment", i-start);
      }

      //mecanisme du fait que le separateur est un espace
      if(OWS(pere->value, &i)){
        start = i;
      }
      else{
        i++;
        start = i; // + 1 pour passer le caractere de separation
      }
    }

    if(pere->value[i] == '(') com += 1;
    else if(pere->value[i] == ')') com -= 1;

    i++;
  }

  return 0;
}

int product_parse(noeud* pere){

  int start = 0;
  int i = 0;
  int slash = 0;

  while(pere->size > i){

    if(((pere->value[i] == '/' && !slash) || pere->size-1 == i)){
      if(pere->size-1 == i && pere->value[i] != '/') i+=1;

      if(!is_token(crFils(pere, pere->value+start, "token", i-start))) return 1 ;
      i++;
      start = i;
      slash = 1;
    }
    if((slash && pere->value[i] == '/') || pere->value[i] == ' '){
      printf("->Erreur synthax dans product\n");
      affNoeud(pere);
      return 1;
    }

    i++;
  }


  return 0;
}

int content_length_parse(noeud* pere){

  int start = 0;
  int i = 0;

  while(i < pere->size){

    if(pere->size-1 == i){
      if(is_digit_sequence(crFils(pere, pere->value+start, "value", i-start))) {
        return 1;
      }
    }

    i++;
  }

  return 0;
}

int content_type_parse(noeud* pere){
  int start = 0;
  int i = 0;

  while(i < pere->size){
    if(pere->size-1 == i){
      if(media_type_parse(crFils(pere, pere->value+start, "media-type", i-start))) {
        return 1;
      }
    }
    i++;
  }

  return 0;
}

int media_type_parse(noeud* pere){
  int start = 0;
  int i = 0;
  int diff = 0;
  int first = 0;

  while(i < pere->size){
    if(pere->value[i] == '/' && !first){
      if(!is_token(crFils(pere, pere->value+start, "type", i-start)))return 1;
      i++;
      start = i;
      first = 1;
    }
    else if(pere->value[i] == ';'){
      if(!is_token(crFils(pere, pere->value+start, "subtype", i-start-diff))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }
    else if(!first && pere->value[i] == ' '){
      printf("->Erreur d'espace\n");
      return 1;
    }
    else if(pere->size-1 == i){
      if(pere->size-1 == i) i++;
      if(parameter_parse(crFils(pere, pere->value+start, "parameter", i-start-diff))) return 1;

    }
    else{
      diff = OWS(pere->value, &i);
      if(diff) i--;
    }

    i++;

  }

  return 0;
}

int parameter_parse(noeud* pere){
  int start = 0;
  int i = 0;

  while (i < pere->size) {
    if(pere->value[i] == '='){
      if(!is_token(crFils(pere, pere->value+start, "token", i-start))) return 1;
      i++;
      start = i;
    }
    if(pere->size-1 == i){
      //Si il faut verifier que c'est un token
      i++;//On doit inclure le char
      if(pere->value[start] != '"'){
        if(!is_token(crFils(pere, pere->value+start, "token", i-start))) return 1;
      }
      else{
        //Verifier quoted string
      }
    }

    i++;
  }

  return 0;
}

int accept_parse(noeud* pere){

  int i = 0;
  int start = 0;
  int diff = 0;
  int pvirg = 0; // Pour savoir si ensuite on cree un media range ou accept param

  if(pere->value[i] == ','){
    i+=1;
    start+=1;
  }

  while(i < pere->size){
    //Si c'est un ; de seperation de media range, accept param
    if(pere->value[i] == ';')
    {
      int j = i;//Pour voir si il y a un q plus loin
      j++;
      OWS(pere->value, &j);

      if(pere->value[j] == 'q'){
        if(media_range_parse(crFils(pere, pere->value+start, "media-range", i-start-diff))) return 1;
        i += 1; // passage du separateur
        OWS(pere->value, &i);
        start = i;
        pvirg = 1;
      }

    }

    if (pere->value[i] == ',' || i == pere->size-1) {
      if(!pvirg) {
        if(media_range_parse(crFils(pere, pere->value+start, "media-range", i-start-diff))) return 1;
      }
      else crFils(pere, pere->value+start, "accept-params", i-start);
      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
      pvirg = 0;
    }
    else{
      diff = OWS(pere->value, &i);
      if(diff) i--;
    }
    i++;
  }

  return 0;
}

int media_range_parse(noeud* pere){
  int i = 0;
  int start = 0;
  int slash = 0;
  int pvirg = 0;
  int diff = 0;

  while(i < pere->size){
    if(pere->value[i] == '/' && pere->value[start] != '*'){
      //Si on doit creer un type
      if(!is_token(crFils(pere, pere->value+start, "type", i-start))) return 1;
      i += 1; // passage du separateur
      start = i;
      slash = 1;
    }
    else if(pere->value[i] == ' ' && !slash){
      printf("->Erreur espace media-range\n");
      return 1;
    }
    else if((pere->value[i] == ';' || pere->size-1 == i) && pere->value[start] != '*' && !pvirg){
      if(pere->size-1 == i) i++; //on doit inclure le dernier caractere
      if(!is_token(crFils(pere, pere->value+start, "subtype", i-start-diff))) return 1;

      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
      pvirg = 1;
    }
    else if((pere->value[i] == ';' || pere->size-1 == i) && pvirg){
      if(pere->size-1 == i) i++;
      if(parameter_parse(crFils(pere, pere->value+start, "parameter", i-start-diff))) return 1;

      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
    }
    else{
      diff = OWS(pere->value, &i);
      if(diff) i--;// obligatoire sinon le ; n'est pas percu
    }

    i++;
  }


  return 0;
}

int accept_params_parse(noeud* pere){



  return 0;
}

int accept_charset_parse(noeud* pere){
  int i = 0;
  int start = 0;
  int diff = 0;
  int pvirg = 0;

  while(pere->value[i] == ','){
    i+=1;
    OWS(pere->value, &i);
  }

  start = i;

  while(i < pere->size){
    if((pere->value[i] == ',' || pere->size-1 == i) && pere->value[start] != '*'){
      if(pvirg){
        if(weight_parse(crFils(pere, pere->value+start, "weight", i-start-diff))) return 1;
      }
      else{
        if(!is_token(crFils(pere, pere->value+start, "charset", i-start-diff))) return 1;
      }

      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
      pvirg = 0;
    }
    else if(pere->value[start] == '*'){
      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
    }
    else if(pere->value[i] == ';'){

      if(!is_token(crFils(pere, pere->value+start, "charset", i-start-diff))) return 1;

      i += 1; // passage du separateur
      OWS(pere->value, &i);
      start = i;
      pvirg = 1;
    }
    else{
      diff = OWS(pere->value, &i);
      if(diff) i--;
    }

    i++;
  }


  return 0;
}

int accept_language_parse(noeud* pere){

  int i = 0;
  int start = 0;
  int pvirg = 0; // Pour savoir si ensuite on cree un media range ou accept param

  // avancer jusqu'a la premiere occurence
  while(pere->value[i] == ','){
    i+=1;
    OWS(pere->value, &i);
  }

  start = i;

  while(i < pere->size){
    //Si c'est un ; de seperation
    if(pere->value[i] == ';')
    {
      if(language_range_parse(crFils(pere, pere->value+start, "language-range", i-start))) return 1;
      start = i + 1;
      pvirg = 1;
    }

    if (pere->value[i] == ',' || i == pere->size-1) {
      if(!pvirg) {
        if(language_range_parse(crFils(pere, pere->value+start, "language-range", i-start))) return 1;
      }
      else{
        if(weight_parse(crFils(pere, pere->value+start, "weight", i-start))) return 1;
      }
      start = i + 1;
      OWS(pere->value, &start);
      pvirg = 0;
    }
    i++;
  }

  return 0;
}

int language_range_parse(noeud* pere){

  int i = 0;
  int tiret = 0;

  if(pere->value[i] != '*'){

    while(i < pere->size){
      if((pere->value[i] == '-' || pere->size-1 == i) && i < 8 && !tiret){
        if(pere->size-1 == i) i++;//inclusion du dernier char
        if(is_alpha_sequence(crFils(pere, pere->value+tiret, "alpha", i-tiret))) return 1;
        i += 1; // passage du separateur
        //OWS(pere->value, &i);
        tiret = i;
      }
      else if(i >= 8 && !tiret){
        printf("->Erreur trop long (1)\n");
        return 1;
      }
      else if(tiret && i-tiret > 8){
        printf("->Erreur trop long (2)\n");
        return 1;
      }
      else if((pere->value[i] == '-' || pere->size-1 == i) && tiret){
        if(pere->size-1 == i) i++;//inclusion du dernier char
        if(is_alphanum_sequence(crFils(pere, pere->value+tiret, "alphanum", i-tiret))) return 1;
        i += 1;
        tiret = i;
      }
      i++;
    }

  }

  return 0;
}

int accept_encoding_parse(noeud* pere){

  int i = 0;
  int start = 0;
  int pvirg = 0; // Pour savoir si ensuite on cree un media range ou accept param

  if(pere->value[i] == ','){
    i+=1;
    start+=1;
  }

  while(i < pere->size){
    //Si c'est un ; de seperation de media range, accept param
    if(pere->value[i] == ';' && (pere->value[i+1] == 'q' || ( pere->value[i+1] == ' ' && pere->value[i+2] == 'q')))
    {
      if(codings_parse(crFils(pere, pere->value+start, "codings", i-start))) return 1;
      start = i + 1;
      OWS(pere->value, &start);
      pvirg = 1;
    }

    if (pere->value[i] == ',' || i == pere->size-1) {
      if(!pvirg) {
        if(codings_parse(crFils(pere, pere->value+start, "codings", i-start)))return 1;
      }
      else {
        if(weight_parse(crFils(pere, pere->value+start, "weight", i-start))) return 1;
      }
      start = i + 1;
      OWS(pere->value, &start);
      pvirg = 0;
    }
    i++;
  }


  return 0;
}

int codings_parse(noeud* pere){

  int i = 0;
  int start = 0;


  if(pere->value[i] == '*'){

  }
  else{
      char* str = strParSize(pere->value, pere->size);
      if(strcmp(str, "identity")){
        if(!is_token(crFils(pere, pere->value+start, "content-coding", pere->size))) return 1;
      }
      free(str);
  }


  return 0;
}

int cookie_parse(noeud* pere){

  int start = 0;
  int i = 0;

  while (i < pere->size) {
    if(pere->value[i] == ';' || pere->size-1 == i){
      if(cookie_pair_parse(crFils(pere, pere->value+start, "cookie-pair", i-start))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }
    else if(pere->value[i] == ' '){
      printf("->Erreur espace\n");
      return 1;
    }

    i++;
  }

  return 0;
}

int cookie_pair_parse(noeud* pere){

  int start = 0;
  int i = 0;

  while (i < pere->size) {
    if(pere->value[i] == '='){
      if(!is_token(crFils(pere, pere->value+start, "cookie-name", i-start))) return 1;
      i++;
      start = i;
    }
    else if(pere->size-1 == i){
      if(pere->size-1 == i) i++;//On doit inclure le char
      //Si le cookie value est entre " "
      char* str = strParSize(pere->fils->value, pere->fils->size);
      if(pere->value[start] == '"'){
        if(is_cookie_sequence(crFils(pere->fils, pere->value+start+1, str, i-start-2))) return 1;
      }
      // Sans " "
      else{
        //Considerons pour le moment un token
        if(is_cookie_sequence(crFils(pere->fils, pere->value+start, str, i-start))) return 1;
      }
      //free(str);
    }

    i++;
  }



  return 0;
}

int transfer_encoding_parse(noeud* pere){
  int i = 0;
  int start = 0;
  int diff=0;

  // avancer jusqu'a la premiere occurence
  while(pere->value[i] == ','){
    i+=1;
    OWS(pere->value, &i);
  }

  start = i;

  while(i < pere->size){

    if(pere->value[i] == ',' || pere->size-1 == i){
      if(transfer_coding_parse(crFils(pere, pere->value+start, "transfer-coding", i-start-diff))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }
    else{
      diff = OWS(pere->value, &i);
      if(diff) i--;
    }

    i++;

  }


  return 0;
}

int transfer_coding_parse(noeud* pere){

  char* str = strParSize(pere->value, pere->size);

  if(strcmp(str, "chunked") && strcmp(str, "compress") && strcmp(str, "deflate") && strcmp(str, "gzip")){
    if(transfer_extension_parse(crFils(pere, pere->value, "transfer-extension", pere->size))) return 1;
  }


  free(str);

  return 0;
}

int transfer_extension_parse(noeud* pere){
  int start = 0;
  int i = 0;
  int diff =0;
  int first = 0;

  while (i < pere->size) {
    if(pere->value[i] == ';' && !first){
      if(!is_token(crFils(pere, pere->value+start, "token", i-start-diff))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }
    if(pere->value[i] == ';' && first){
      if(transfer_parameter_parse(crFils(pere, pere->value+start, "transfer-parameter", i-start-diff))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }

    else{
      diff = OWS(pere->value, &i);
    }

    i++;
  }

  return 0;



  return 0;
}

int transfer_parameter_parse(noeud* pere){
  int start = 0;
  int i = 0;
  int diff =0;

  while (i < pere->size) {
    if(pere->value[i] == '='){
      if(!is_token(crFils(pere, pere->value+start, "token", i-start-diff))) return 1;
      i++;
      OWS(pere->value, &i);
      start = i;
    }
    else if(pere->size-1 == i){
      //Si il faut verifier que c'est un token
      if(pere->value[start] != '"'){
        if(!is_token(crFils(pere, pere->value+start, "token", i-start))) return 1;
      }
      else{
        //Verifier quoted string
      }
    }
    else{
      diff = OWS(pere->value, &i);
    }

    i++;
  }

  return 0;

}

int expect_parse(noeud* pere){

  char* str = strParSize(pere->value, pere->size-1);// -1 pour le retour chariot parasite

  if(strcmp(str, "100-continue")){
    printf("->Erreur expect header field\n");
    return 1;
  }

  free(str);

  return 0;
}

int host_parse(noeud* pere){
  int start = 0;
  int i = 0;
  int diff =0;
  int first = 0;

  while (i < pere->size) {
    if((pere->value[i] == ':' || pere->size-1 == i) && !first){

      //HOST A VERIFIER
      crFils(pere, pere->value+start, "uri-host", i-start-diff);

      i++;
      start = i;
      first = 1;
    }
    else if(pere->size-1 == i && first){
      if(is_digit_sequence(crFils(pere, pere->value+start, "port", i-start))) return 1;
    }
    else if(pere->value[i] == ' '){
      printf("->Erreur espace host\n");
      return 1;
    }

    i++;
  }

  return 0;



  return 0;
}

int weight_parse(noeud* pere){

  int i = 0;

  while (i < pere->size && pere->value[i] != '=') {
    i++;
  }
  i++;

  if(is_qvalue(crFils(pere, pere->value+i, "qvalue", pere->size-i))) return 1;

  return 0;
}

int referer_parse(noeud* pere){

  int i = 0;

  if(pere->value[i] == '/' && pere->value[i+1] == '/'){
    if(partial_uri(crFils(pere, pere->value, "partial-URI", pere->size-1))) return 1;
  }
  else{
    if(absolute_uri(crFils(pere, pere->value, "absolute-URI", pere->size-1))) return 1;
  }

  return 0;
}

int absolute_uri(noeud* pere){

  int i = 0;
  int start = 0;
  int point2 = 0;
  int pointInt = 0;

  while(i < pere->size){
    if(pere->value[i] == ':'){

      if(scheme_parse(crFils(pere, pere->value+start, "scheme", i-start))) return 1;
      i++;
      start = i;
      point2 = 1;
    }
    else if((pere->value[i] == '?' || (pere->size-1 == i && !pointInt)) && point2){
      if(pere->size-1 == i) i++;

      if(hier_part_parse(crFils(pere, pere->value+start, "hier-part", i-start))) return 1;
      i++;
      start = i;
      pointInt++;
    }
    else if((pere->value[i] == '?' || pere->size-1 == i) && pointInt){
      if(pere->size-1 == i) i++;
      if(query_parse(crFils(pere, pere->value+start, "query", i-start))) return 1;
      i++;
      start = i;
    }
    i++;
  }

  return 0;
}

int partial_uri(noeud* pere){

  int i = 0;
  int start = 0;
  int pointInt = 0;

  while(i < pere->size){

    if((pere->value[i] == '?' || pere->size-1 == i) && !pointInt){
      if(pere->size-1 == i) i++;

      if(relative_part_parse(crFils(pere, pere->value+start, "relative-part", i-start))) return 1;
      i++;
      start = i;
      pointInt = 1;
    }
    else if((pere->value[i] == '?' || pere->size-1 == i) && pointInt){
      if(pere->size-1 == i) i++;
      if(query_parse(crFils(pere, pere->value+start, "query", i-start))) return 1;
      i++;
      start = i;
    }
    i++;
  }


  return 0;
}

int scheme_parse(noeud* pere){


  return 0;
}

int hier_part_parse(noeud* pere){


  return 0;
}

int query_parse(noeud* pere){


  return 0;
}

int relative_part_parse(noeud* pere){


  return 0;
}


int unkw_field_parse(noeud* pere){

  char* str = pere->field;
  int i = 0;

  while(str[i] != '\0'){
    if(!is_tchar(str[i])){
      printf("->Erreur token, %c\n", str[i]);
      affNoeud(pere);
      return 1;
    }

    i++;
  }

  crFils(pere, pere->value, "field-value", pere->size-1);


  return 0;
}





int OWS(char* p, int* i){
  int tmp = *i;
  while(p[*i] == ' ' || p[*i] == '\t'){
    (*i)++;
  }
  //vrai = changement
  //renvoi en + le nombre de deplacement
  return (*i)-tmp; // renvoi vrai ou faux selon s'il y a eu modification ou non
}

int is_token(noeud* pere){
  for(int i = 0; i < pere->size; i++){
    if(!is_tchar(pere->value[i])){
      printf("->Erreur token, %c\n", pere->value[i]);
      affNoeud(pere);
      return 0;
    }
  }

  return 1;
}

int is_tchar(char c){
  if(c == '!'
      || c == '#'
      || c == '$'
      || c == '%'
      || c == '&'
      || c == '\''
      || c == '*'
      || c == '+'
      || c == '-'
      || c == '.'
      || c == '^'
      || c == '_'
      || c == '`'
      || c == '|'
      || c == '~'
      || is_digit(c)
      || is_alpha(c)) return 1;

  else return 0;
}

int is_digit(char c){
  if(c > 47 && c < 58) return 1;
  else return 0;
}

int is_alpha(char c){
  if((c > 64 && c < 91) || (c > 96 && c < 123)) return 1;
  else return 0;
}

int is_alpha_sequence(noeud* pere){

  int i = 0;

  while(i < pere->size){
    if(!is_alpha(pere->value[i])){
      printf("->Erreur caractere, %c\n", pere->value[i]);
      affNoeud(pere);
      return 1;
    }
    i++;
  }

  return 0;
}

int is_alphanum_sequence(noeud* pere){

  int i = 0;

  while(i < pere->size){
    if(!is_alpha(pere->value[i]) && !is_digit(pere->value[i])){
      printf("->Erreur caractere, %c\n", pere->value[i]);
      affNoeud(pere);
      return 1;
    }
    i++;
  }

  return 0;
}

int is_digit_sequence(noeud* pere){

  for(int i = 0; i < pere->size; i++){
    if(!is_digit(pere->value[i])){
      printf("->Erreur digit sequence\n");
      return 1;
    }
  }

  return 0;
}

int is_qvalue(noeud* pere){

  int i = 0;

  if(pere->value[i] == '1'){
    i++;
    if(i < pere->size && pere->value[i] == '.'){
      i++;
      while(i < pere->size && i < 6){
        if(pere->value[i] != '0'){
          printf("->Erreur valeur q\n");
          return 1;
        }
        i++;
      }
      if(i >= 6){
        printf("->Erreur q trop long\n");
        return 1;
      }
    }
    else if(i < pere->size){
      printf("->Erreur format qvalue\n");
      return 1;
    }

  }
  else if(pere->value[0] == '0'){
    i++;
    if(i < pere->size && pere->value[i] == '.'){
      i++;
      while(i < pere->size && i < 6){
        if(!is_digit(pere->value[i])){
          printf("->Erreur valeur q\n");
          return 1;
        }
        i++;
      }
      if(i >= 6){
        printf("->Erreur q trop long\n");
        return 1;
      }
    }
    else if(i < pere->size){
      printf("->Erreur format qvalue\n");
      return 1;
    }
  }
  else{
    printf("->Erreur valeur q\n");
    return 1;
  }


  return 0;
}

int is_cookie_sequence(noeud* pere){

  for(int i = 0; i < pere->size; i++){
    if(!is_cookie_octet(pere->value[i])){
      printf("->Erreur cookie sequence\n");
      affNoeud(pere);
      return 1;
    }
  }

  return 0;
}

int is_cookie_octet(char c){
	return 	(c == 0x21 || (c >= 0x23 && c <= 0x2B) || (c >= 0x2D && c <= 0x3A) || (c >= 0x3C && c <= 0x5B) || (c >= 0x5D && c <= 0x7E));
}
