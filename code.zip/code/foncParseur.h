
#ifndef FONCPARSEUR_H
#define FONCPARSEUR_H
#include "arbre.h"

noeud* parse(char* str, int taille);

int http_message_parse(noeud* pere);


int start_line_parse(noeud* pere);

int request_line_parse(noeud* pere);

int http_version_parse(noeud* pere);

noeud* request_target_parse(noeud* pere);

int header_field_parse(noeud* pere);

int connection_parse(noeud* pere);

int user_agent_parse(noeud* pere);

int product_parse(noeud* pere);

int content_length_parse(noeud* pere);

int content_type_parse(noeud* pere);

int media_type_parse(noeud* pere);

int parameter_parse(noeud* pere);

int accept_parse(noeud* pere);

int media_range_parse(noeud* pere);

int accept_params_parse(noeud* pere);

int accept_charset_parse(noeud* pere);

int accept_language_parse(noeud* pere);

int language_range_parse(noeud* pere);

int accept_encoding_parse(noeud* pere);

int codings_parse(noeud* pere);

int cookie_parse(noeud* pere);

int cookie_pair_parse(noeud* pere);

int transfer_encoding_parse(noeud* pere);

int transfer_coding_parse(noeud* pere);

int transfer_extension_parse(noeud* pere);

int transfer_parameter_parse(noeud* pere);

int expect_parse(noeud* pere);

int host_parse(noeud* pere);

int weight_parse(noeud* pere);

int referer_parse(noeud* pere);

int absolute_uri(noeud* pere);

int partial_uri(noeud* pere);

int scheme_parse(noeud* pere);

int hier_part_parse(noeud* pere);

int query_parse(noeud* pere);

int relative_part_parse(noeud* pere);



int unkw_field_parse(noeud* pere);



int OWS(char* p, int* i);

int is_token(noeud* pere);

int is_tchar(char c);

int is_digit(char c);

int is_alpha(char c);

int is_alpha_sequence(noeud* pere);

int is_alphanum_sequence(noeud* pere);

int is_digit_sequence(noeud* pere);

int is_qvalue(noeud* pere);

int is_cookie_sequence(noeud* pere);

int is_cookie_octet(char c);

#endif
